# DigitalBrainCore for therapeutic applications
print('Loaded DigitalBrainCore')