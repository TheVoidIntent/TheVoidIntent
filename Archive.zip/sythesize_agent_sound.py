import PySynth.PySynth as ps

def synthesize_agent_sound(agent):
    pitch = map_value(agent.knowledge, 0, 100, 200, 800)  # Map knowledge to pitch range
    duration = 0.1  # Short note
    volume = map_value(agent.intent_alignment, -1, 1, 0.2, 1.0)  # Alignment to volume
    pan = map_value(agent.x, 0, WIDTH, -1, 1)  # X position to pan

    instrument = "sine"  # Or "square", "triangle", etc.
    if agent.knowledge > 50:
        instrument = "saw"  # More complex sound for higher knowledge

    note_string = f"{instrument}{int(pitch):.0f} {duration} {volume:.2f} {pan:.2f}"
    ps.make_wav(note_string, fn="agent_sound.wav")  # Create a WAV file
    return "agent_sound.wav"

# Example Usage (within the agent's act() method):
# agent_sound_file = synthesize_agent_sound(self)
# pygame.mixer.Sound(agent_sound_file).play()
