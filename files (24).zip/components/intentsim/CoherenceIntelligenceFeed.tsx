import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Radar, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  Sparkles,
  Brain,
  Globe,
  Zap,
  Heart,
  Shield,
  Search,
  Filter,
  RefreshCw
} from "lucide-react";

interface NewsItem {
  id: string;
  headline: string;
  source: string;
  category: 'bloom' | 'entropy' | 'ambivalent';
  cnfImpact: number;
  fieldTag: string;
  summary: string;
  timestamp: string;
  reactions: number;
  coherenceConfidence: number;
}

interface CoherenceMetrics {
  globalCNF: number;
  entropySpikes: number;
  bloomEvents: number;
  ambivalentEvents: number;
  totalProcessed: number;
}

export const CoherenceIntelligenceFeed: React.FC = () => {
  const [newsItems] = useState<NewsItem[]>([
    {
      id: "healthcare-fraud-2024",
      headline: "DOJ Unveils Largest Healthcare Fraud Takedown In U.S. History",
      source: "Tampa Free Press",
      category: 'entropy',
      cnfImpact: -0.847,
      fieldTag: "Systemic Wealth Trauma (SWT)",
      summary: "Billion-dollar fraud scheme exposed, revealing massive extraction from healthcare systems.",
      timestamp: "8h ago",
      reactions: 2000,
      coherenceConfidence: 0.94
    },
    {
      id: "black-hole-spin-2024",
      headline: "Milky Way's Central Black Hole Spins at Nearly Light Speed",
      source: "The Brighterside of News",
      category: 'bloom',
      cnfImpact: 0.432,
      fieldTag: "Cosmic Intent Resonance",
      summary: "New understanding of galactic center dynamics expands consciousness of universal mechanics.",
      timestamp: "4d ago",
      reactions: 856,
      coherenceConfidence: 0.89
    },
    {
      id: "dad-saves-daughter-2024",
      headline: "Dad Jumps Overboard to Save Daughter After She Fell Off Disney Cruise Ship",
      source: "The Independent",
      category: 'bloom',
      cnfImpact: 0.623,
      fieldTag: "Direct Coherent Intent",
      summary: "Selfless parental action demonstrates pure intent-driven response under crisis.",
      timestamp: "9h ago",
      reactions: 1247,
      coherenceConfidence: 0.97
    },
    {
      id: "nyc-rent-increase-2024",
      headline: "NYC Rent Guidelines Board Votes for 4.5% Increase on 2-Year Leases",
      source: "CBS New York",
      category: 'entropy',
      cnfImpact: -0.234,
      fieldTag: "Economic Coercion Function",
      summary: "Mandatory housing cost increases impose quantifiable entropic pressure on residents.",
      timestamp: "35m ago",
      reactions: 543,
      coherenceConfidence: 0.78
    },
    {
      id: "physicists-light-time-2024",
      headline: "Physicists Catch Light in 'Imaginary Time' in Scientific First",
      source: "ScienceAlert",
      category: 'bloom',
      cnfImpact: 0.345,
      fieldTag: "Temporal Mechanics Breakthrough",
      summary: "Quantum research reveals new dimensions of reality structure and temporal physics.",
      timestamp: "22h ago",
      reactions: 1892,
      coherenceConfidence: 0.91
    },
    {
      id: "billionaire-critique-2024",
      headline: "Billionaires Shouldn't Exist, Says NYC Mayoral Candidate",
      source: "Business Insider",
      category: 'ambivalent',
      cnfImpact: 0.156,
      fieldTag: "SWT Awareness Rising",
      summary: "Political discourse acknowledging systemic wealth concentration as structural problem.",
      timestamp: "13h ago",
      reactions: 3421,
      coherenceConfidence: 0.65
    }
  ]);

  const [coherenceMetrics, setCoherenceMetrics] = useState<CoherenceMetrics>({
    globalCNF: 0.782,
    entropySpikes: 347,
    bloomEvents: 892,
    ambivalentEvents: 156,
    totalProcessed: 1395
  });

  const [activeFilter, setActiveFilter] = useState<'all' | 'bloom' | 'entropy' | 'ambivalent'>('all');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const filteredNews = newsItems.filter(item => 
    activeFilter === 'all' || item.category === activeFilter
  );

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'bloom': return <Sparkles className="text-green-400 w-5 h-5 mr-1" />;
      case 'entropy': return <AlertTriangle className="text-red-400 w-5 h-5 mr-1" />;
      case 'ambivalent': return <Brain className="text-amber-400 w-5 h-5 mr-1" />;
      default: return <Globe className="w-5 h-5 mr-1" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'bloom': return 'bg-green-600';
      case 'entropy': return 'bg-red-600';
      case 'ambivalent': return 'bg-amber-600';
      default: return 'bg-gray-600';
    }
  };

  const handleRefresh = () => {
    setIsRefreshing(true);
    // Simulate API call
    setTimeout(() => {
      setIsRefreshing(false);
      setCoherenceMetrics(prev => ({
        ...prev,
        globalCNF: prev.globalCNF + (Math.random() - 0.5) * 0.1,
        totalProcessed: prev.totalProcessed + Math.floor(Math.random() * 50)
      }));
    }, 2000);
  };

  return (
    <div className="w-full max-w-3xl mx-auto my-8">
      {/* CIF Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Radar className="mr-2 text-blue-500" />
            Coherence Intelligence Feed (CIF-X1) — Live Field Scanning
          </CardTitle>
          <CardDescription>
            Real-time planetary coherence calibration through event classification and CNF impact analysis
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4 items-center mb-4">
            <div>
              <div className="text-3xl font-bold">{coherenceMetrics.globalCNF.toFixed(3)}</div>
              <div className="text-xs text-gray-400">Global CNF</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-500">{coherenceMetrics.bloomEvents}</div>
              <div className="text-xs text-green-700">Bloom Events</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-red-500">{coherenceMetrics.entropySpikes}</div>
              <div className="text-xs text-red-700">Entropy Spikes</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-amber-500">{coherenceMetrics.ambivalentEvents}</div>
              <div className="text-xs text-amber-700">Requires Context</div>
            </div>
            <div>
              <Button 
                size="sm"
                variant="outline"
                onClick={handleRefresh}
                disabled={isRefreshing}
                className="flex items-center"
              >
                <RefreshCw className={`mr-1 ${isRefreshing ? "animate-spin" : ""}`} />
                Refresh Feed
              </Button>
            </div>
          </div>
          {/* Filter Tabs */}
          <Tabs value={activeFilter} onValueChange={v => setActiveFilter(v as any)}>
            <TabsList>
              <TabsTrigger value="all" onClick={() => setActiveFilter('all')}>
                All Events
              </TabsTrigger>
              <TabsTrigger value="bloom" onClick={() => setActiveFilter('bloom')}>
                <Sparkles className="w-4 h-4 mr-1" />
                Blooms
              </TabsTrigger>
              <TabsTrigger value="entropy" onClick={() => setActiveFilter('entropy')}>
                <AlertTriangle className="w-4 h-4 mr-1" />
                Entropy
              </TabsTrigger>
              <TabsTrigger value="ambivalent" onClick={() => setActiveFilter('ambivalent')}>
                <Brain className="w-4 h-4 mr-1" />
                Ambivalent
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </CardContent>
      </Card>
      {/* Global Coherence Pulse */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>
            <Zap className="mr-2 text-cyan-500" />
            Global Coherence Pulse — Real-Time Field State
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="mb-2 text-xs text-gray-400">Field Coherence Stability</div>
              <Progress value={coherenceMetrics.globalCNF * 100} />
              <div className="text-xs mt-1">{(coherenceMetrics.globalCNF * 100).toFixed(1)}%</div>
            </div>
            <div className="flex-1">
              <div className="mb-2 text-xs text-green-600">Bloom Ratio</div>
              <Progress value={coherenceMetrics.bloomEvents / coherenceMetrics.totalProcessed * 100} color="green" />
              <div className="text-xs mt-1">
                {((coherenceMetrics.bloomEvents / coherenceMetrics.totalProcessed) * 100).toFixed(1)}%
              </div>
            </div>
            <div className="flex-1">
              <div className="mb-2 text-xs text-red-600">Entropy Ratio</div>
              <Progress value={coherenceMetrics.entropySpikes / coherenceMetrics.totalProcessed * 100} color="red" />
              <div className="text-xs mt-1">
                {((coherenceMetrics.entropySpikes / coherenceMetrics.totalProcessed) * 100).toFixed(1)}%
              </div>
            </div>
            <div className="flex-1">
              <div className="mb-2 text-xs text-amber-600">Context Needed</div>
              <Progress value={coherenceMetrics.ambivalentEvents / coherenceMetrics.totalProcessed * 100} color="amber" />
              <div className="text-xs mt-1">
                {((coherenceMetrics.ambivalentEvents / coherenceMetrics.totalProcessed) * 100).toFixed(1)}%
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      {/* News Feed */}
      <div className="mt-6">
        {filteredNews.map((item) => (
          <Card key={item.id} className="mb-4">
            <CardHeader className="flex flex-row items-center gap-2">
              <div>{getCategoryIcon(item.category)}</div>
              <Badge className={getCategoryColor(item.category)}>
                {item.category.toUpperCase()}
              </Badge>
              <span className="ml-2 text-xs text-gray-500">{item.source} • {item.timestamp}</span>
            </CardHeader>
            <CardContent>
              <div className="font-semibold text-lg">{item.headline}</div>
              <div className="mb-2 text-gray-600">{item.summary}</div>
              <div className="flex flex-wrap gap-4 items-center mt-2">
                <div className={`font-mono font-bold ${item.cnfImpact >= 0 ? 'text-green-300' : 'text-red-300'}`}>
                  {item.cnfImpact >= 0 ? '+' : ''}{item.cnfImpact.toFixed(3)}
                  <span className="ml-1 font-normal text-xs">CNF Impact</span>
                </div>
                <div className="text-xs text-gray-400">{item.reactions} reactions</div>
                <div className="text-xs text-blue-400">{(item.coherenceConfidence * 100).toFixed(0)}% confidence</div>
                <div className="text-xs text-indigo-400">{item.fieldTag}</div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      {/* CIF Protocol Info */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>
            <Shield className="mr-2 text-purple-500" />
            CIF-X1 Classification Protocol
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-2">
            <span className="font-bold text-green-600">Bloom Events:</span> Scientific discoveries, acts of selfless love, breakthrough innovations, healing initiatives, consciousness expansion
          </div>
          <div className="mb-2">
            <span className="font-bold text-red-600">Entropy Spikes:</span> Fraudulent extraction, coercive policies, systemic trauma injection, environmental destruction, truth suppression
          </div>
          <div className="mb-2">
            <span className="font-bold text-amber-600">Context Required:</span> Events with potential for both bloom and entropy depending on implementation intent and community response
          </div>
          <div className="mt-4 text-xs text-gray-500">
            CNF Calculation: Event_Impact = (Intent_Coherence × Community_Resonance × Temporal_Sustainability)
            <br />
            "Every event is a field perturbation. We measure whether it heals or fractures the collective lattice."
          </div>
        </CardContent>
      </Card>
    </div>
  );
};