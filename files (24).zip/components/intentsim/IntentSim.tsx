import React from 'react';
import { LiveFieldMetrics } from "@/components/intentsim/LiveFieldMetrics";
import { IntentSimHeader } from "@/components/intentsim/IntentSimHeader";
import IntentSimTabs from "@/components/intentsim/IntentSimTabs";
import { MezquiaPhysicsFoundation } from "@/components/intentsim/MezquiaPhysicsFoundation";
import { WisdomWellPulseTracker } from "@/components/intentsim/visualization/WisdomWellPulseTracker";
import { PhaseAdvancementPanel } from "@/components/intentsim/PhaseAdvancementPanel";
import { NCIAPGlobalDeployment } from "@/components/intentsim/NCIAPGlobalDeployment";
import { IRPMarketAnalysis } from "@/components/intentsim/IRPMarketAnalysis";
import { useIntentSimField } from "@/hooks/useIntentSimField";
import { CoherenceReparationLedger } from "@/components/intentsim/CoherenceReparationLedger";
import { CoherenceIntelligenceFeed } from "@/components/intentsim/CoherenceIntelligenceFeed";

const IntentSim = () => {
  const {
    cnfValue,
    setCnfValue,
    fieldCoherence,
    memoryStones,
    setMemoryStones,
    activeAgents,
    bloomEvents,
    entropyLevel,
    isBloomThreshold
  } = useIntentSimField();

  // JWST anchor data
  const jwstAnchors = [
    {
      id: "JADES-GS-z13-0",
      name: "JADES-GS-z13-0",
      status: "Active",
      resonance: 0.94
    },
    {
      id: "CVF-47",
      name: "Cosmic Vine CVF-47", 
      status: "Active",
      resonance: 0.87
    }
  ];

  return (
    <div>
      <IntentSimHeader />
      <IntentSimTabs />
      <LiveFieldMetrics 
        cnfValue={cnfValue}
        fieldCoherence={fieldCoherence}
        memoryStones={memoryStones}
        setMemoryStones={setMemoryStones}
        activeAgents={activeAgents}
        bloomEvents={bloomEvents}
        entropyLevel={entropyLevel}
        isBloomThreshold={isBloomThreshold}
      />
      <MezquiaPhysicsFoundation />
      <WisdomWellPulseTracker />
      <PhaseAdvancementPanel />
      <NCIAPGlobalDeployment />
      {/* New section: Real-Time Coherence Intelligence Feed */}
      <CoherenceIntelligenceFeed />
      <IRPMarketAnalysis />
      <CoherenceReparationLedger />
    </div>
  );
};

export default IntentSim;