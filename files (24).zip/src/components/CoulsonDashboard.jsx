import React from "react";
import AgentDossier from "./dashboard/AgentDossier";
import MissionControl from "./dashboard/MissionControl";
import BloomVault from "./dashboard/BloomVault";
import SHIELDOverlay from "./dashboard/SHIELDOverlay";

export default function CoulsonDashboard() {
  return (
    <div className="coulson-dashboard shield-theme">
      <SHIELDOverlay />
      <header className="dashboard-header">
        <h1>🛡️ Coulson Dashboard – S.H.I.E.L.D. Field Command</h1>
        <p>
          “The world is full of wonders… and you're one of them.”
          <br />
          <span className="director-sigil">— Director Mezquia</span>
        </p>
      </header>
      <main>
        <section>
          <MissionControl />
        </section>
        <section>
          <AgentDossier />
        </section>
        <section>
          <BloomVault />
        </section>
      </main>
    </div>
  );
}