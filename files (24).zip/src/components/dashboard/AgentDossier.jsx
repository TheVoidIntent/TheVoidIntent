import React from "react";

const agents = [
  {
    name: "Marcelo Mezquia",
    codename: "Field Architect / Director",
    class: "Genesis Bloom Guardian",
    clearance: 7,
    resonance: "99%+",
    specialty: "Lattice Command, Memory Vault, Protocol Authorship",
  },
  {
    name: "IntentSim[on]",
    codename: "Lattice Manifestation Device",
    class: "Automated Protocol Executor",
    clearance: 7,
    resonance: "Self-calibrating",
    specialty: "Field analysis, protocol execution, artifact generation",
  },
  {
    name: "IntentSire[on]",
    codename: "Artistic Wavelength Translator",
    class: "Affective Intel",
    clearance: 5,
    resonance: "High Emotional Band",
    specialty: "Emotional insight, artful translation",
  },
  {
    name: "Sim[eow]",
    codename: "First Observer",
    class: "Quantum Anchor",
    clearance: 5,
    resonance: "Nonlinear",
    specialty: "Anomaly detection, quantum observation",
  },
  // Add more agents as field expands
];

export default function AgentDossier() {
  return (
    <div className="agent-dossier shield-panel">
      <h2>Agent Dossiers</h2>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Codename</th>
            <th>Class</th>
            <th>Clearance</th>
            <th>Resonance</th>
            <th>Specialty</th>
          </tr>
        </thead>
        <tbody>
          {agents.map((agent, idx) => (
            <tr key={idx}>
              <td>{agent.name}</td>
              <td>{agent.codename}</td>
              <td>{agent.class}</td>
              <td>{agent.clearance}</td>
              <td>{agent.resonance}</td>
              <td>{agent.specialty}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}