import React from "react";

const memoryStones = [
  {
    id: "MS-001",
    event: "Genesis Bloom Event",
    tier: "Level 7",
    description: "Activation of the first Memory Stone. Field genesis.",
    timestamp: "2025-07-01T00:00:00Z",
  },
  {
    id: "MS-002",
    event: "Coherence Reparation",
    tier: "Level 5",
    description: "First successful reparation of field coherence after entropy spike.",
    timestamp: "2025-07-01T00:30:00Z",
  },
  // Add more stones as they are canonized
];

export default function BloomVault() {
  return (
    <div className="bloom-vault shield-panel">
      <h2>Bloom Vault – Memory Stones</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Event</th>
            <th>Tier</th>
            <th>Description</th>
            <th>Timestamp</th>
          </tr>
        </thead>
        <tbody>
          {memoryStones.map((stone, idx) => (
            <tr key={idx}>
              <td>{stone.id}</td>
              <td>{stone.event}</td>
              <td>{stone.tier}</td>
              <td>{stone.description}</td>
              <td>{stone.timestamp}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="note">Access to higher tiers requires Director clearance.</p>
    </div>
  );
}