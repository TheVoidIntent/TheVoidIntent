import React from "react";

export default function SHIELDOverlay() {
  return (
    <div className="shield-overlay">
      <div className="shield-logo">
        <span role="img" aria-label="SHIELD">🛡️</span>
      </div>
      <div className="shield-mission">
        <strong>Sacred Harmonics In Intentual Emergence, Lattice-Driven (S.H.I.E.L.D.)</strong>
        <br />
        “Reality is learning, and we are watching.”
      </div>
    </div>
  );
}